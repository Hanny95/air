package com.edu.air.member.dao;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.edu.air.member.vo.MemberVo;

@Component
public class MemberDao {
	
	
	public final static int MEMBER_IS = 1;
	public final static int MEMBER_IS_NOT = 0;
	public final static int MEMBER_INSERT_SUCCESS = 2;
	public final static int MEMBER_INSERT_FAIL = 3;
	
	@Autowired
	JdbcTemplate jdbcTemplat;
	
	public int insertMember(MemberVo memberVo) {
		
		System.out.println("[MemberDao] insertMember() INIT! ");
		
		String sql = "INSERT INTO tbl_member(m_mail, m_pw, m_reg_date, m_mod_date) "
				+ "VALUES(?, ?, NOW(), NOW())";
		
		int result = jdbcTemplat.update(sql, 
										memberVo.getM_mail(), 
										memberVo.getM_pw());
				
		
		if(result > 0) {
			return MEMBER_INSERT_SUCCESS;
			
		} else {
			return MEMBER_INSERT_FAIL;
			
		}
	
	}

	
	
	public boolean isMember(MemberVo memberVo) {
		
		int result = 0;
			
		String sql = "SELECT COUNT(*) FROM tbl_member WHERE m_mail=?";
		
		result = jdbcTemplat.queryForObject(sql, Integer.class, memberVo.getM_mail());
		
		return result > 0 ? true : false;
		


	}



	public int loginMember(MemberVo memberVo) {
		
		int result = 0;
		
		String sql = "SELECT COUNT(*) FROM tbl_member WHERE m_mail=? and m_pw=?";
		
		result = jdbcTemplat.queryForObject(sql, Integer.class, memberVo.getM_mail(), memberVo.getM_pw());
		
		return result;
	}
	
	

}
