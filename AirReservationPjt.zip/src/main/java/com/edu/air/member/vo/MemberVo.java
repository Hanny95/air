package com.edu.air.member.vo;

public class MemberVo {
	
	
	private int m_no;
	private String m_mail;
	private String m_pw;
	private String m_reg_date;
	private String m_mod_date;
	
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getM_mail() {
		return m_mail;
	}
	public void setM_mail(String m_mail) {
		this.m_mail = m_mail;
	}
	public String getM_pw() {
		return m_pw;
	}
	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}
	public String getM_reg_date() {
		return m_reg_date;
	}
	public void setM_reg_date(String m_reg_date) {
		this.m_reg_date = m_reg_date;
	}
	public String getM_mod_date() {
		return m_mod_date;
	}
	public void setM_mod_date(String m_mod_date) {
		this.m_mod_date = m_mod_date;
	}
	
	
	
	
	
}
