package com.edu.air.admin.vo;

public class AdminVo {
	
	
	private int a_no;
	private String a_mail;
	private String a_pw;
	private String a_reg_date;
	private String a_mod_date;
	
	
	public int getA_no() {
		return a_no;
	}
	public void setA_no(int a_no) {
		this.a_no = a_no;
	}
	public String getA_mail() {
		return a_mail;
	}
	public void setA_mail(String a_mail) {
		this.a_mail = a_mail;
	}
	public String getA_pw() {
		return a_pw;
	}
	public void setA_pw(String a_pw) {
		this.a_pw = a_pw;
	}
	public String getA_reg_date() {
		return a_reg_date;
	}
	public void setA_reg_date(String a_reg_date) {
		this.a_reg_date = a_reg_date;
	}
	public String getA_mod_date() {
		return a_mod_date;
	}
	public void setA_mod_date(String a_mod_date) {
		this.a_mod_date = a_mod_date;
	}
	
	
	
	
	
	
}
