package com.edu.air.admin.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.edu.air.admin.service.AdminService;
import com.edu.air.admin.vo.AdminVo;

@Controller
@RequestMapping(value="/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@RequestMapping(value= "/", method = RequestMethod.GET)
	public String adminHome() {
		
		System.out.println("[AdminController] adminHome() INIT!");
		
		return "admin/loginForm";
	}
	
	@RequestMapping(value="/loginConfirm", method=RequestMethod.POST)
	public String loginConfirm(AdminVo adminVo, HttpSession session) {
		
		System.out.println("[AdminController] loginConfirm() INIT!");
		
		int result = adminService.loginConfirm(adminVo);
		
		if (result > 0 ) {
			
			session.setAttribute("admin", adminVo.getA_mail());
			
			return "redirect:/admin/";
			
		} else {
			
			return "redirect:/admin/";
		}
	
	}
	
}
