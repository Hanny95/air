package com.edu.air.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.air.admin.dao.AdminDao;
import com.edu.air.admin.vo.AdminVo;

@Service
public class AdminService {

	@Autowired
	AdminDao adminDao;
	
	
	public int loginConfirm(AdminVo adminVo) {
		
		
		int result = adminDao.loginAdmin(adminVo);
	
		return result;
		
	}

}
